import React from 'react'

function CardPage() {
  return (
    <div>CardPage</div>
  )
}

export default CardPage