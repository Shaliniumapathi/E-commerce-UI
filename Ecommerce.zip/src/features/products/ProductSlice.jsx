import Product from '../../ProductsContent'
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    items: Product,
    filterItem: Product,
    searchTerms: "",
    selectedCategory: "All",

};

const filterProducts =(state)=>{
    return state.items.filter((products) =>{
        const matchSearch =products.title
        .toLowerCase()
        .includes(state.searchTerms.toLowerCase());
        const matchCategory=state.selectedCategory==="All" || products.category===state.selectedCategory;
        return matchSearch && matchCategory;

    });
};
const ProductSlice=createSlice({
    name: "products",
    initialState,
    reducers: {
        setSearchTerms: (state, action) => {
            state.searchTerms = action.payload;
            state.filterItem = filterProducts(state);     
        },  
        setSearchCategory: (state, action) => {
            state.selectedCategory = action.payload;
            state.filterItem = filterProducts(state);
        }
        },
});

export const { setSearchTerms, setSearchCategory } = ProductSlice.actions;
export default ProductSlice.reducer;

