import { BrowserRouter, Routes as Routs, Route } from 'react-router-dom'
import Home from './Pages/Home.jsx'
import ProductDetails from './pages/ProductDetails.jsx'
import CardPage from './pages/CardPage.jsx'
import Navbar from './Components/Navbar.jsx'
import './App.css'
import { Provider } from 'react-redux'
import {store} from './App/Store.js'

function App() {
 

  return (
    <Provider store={store}>
      <BrowserRouter>
    <Navbar/>
      <Routs>
        <Route path='/' element={<Home/>} />
        <Route path="/product" element={<ProductDetails/>} />
        <Route path="/card" element={<CardPage/>} />
      </Routs>
    </BrowserRouter>
    </Provider>
  )
}

export default App
