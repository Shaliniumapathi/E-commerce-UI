import React from 'react'
import { Link } from 'react-router-dom'

function ProductCard({ product }) {
  return (
    <Link>
        <div className='shadow lg rounded-md cursor-pointer'>
            <img src={product.images[0]} alt={product.title} style={{ width:'100%', height:'350px' }}/>
            <div className='bg-gray-50 p-4'>
              <h2 className='text-lg font-semibold my-4'>{product.title.substring(0, 20) + "..."}</h2>
              <p className='text-sm text-zinc-500 border-b-2 pb-4'>{product.description.substring(0, 70) + "..."}</p>
              <div className='flex justify-between mt-4 items-center'>
                <p className='text-lg font-semibold'>${product.price}</p>
                <p>View Details</p>
              </div>
            </div> 
        </div>
    </Link>
  )
}

export default ProductCard